package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class dbcon {
	public static Connection getConnection()
	{
		Connection con=null;
		try
		{
			System.out.println("inside get connected");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("connected");
			con=DriverManager.getConnection("jdbc:mysql://localhost/briga","root","");
			System.out.println("connected");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
