package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.regmodel;

import connection.dbcon;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;

public class regservice {
	Connection con=dbcon.getConnection();
	
	public int senMail(String mail,String pswd,String name) throws Exception
	   {
	        final String username = "brigahospital@gmail.com";
	        final String password = "BrigaHospital@19";
	 
	        Properties props = new Properties();
	        props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
	 
			Session session = Session.getInstance(props,new javax.mail.Authenticator() {
	            @Override
	        protected PasswordAuthentication getPasswordAuthentication() {
	        return new PasswordAuthentication(username, password);}});
	    
	        try
	        {
	        	String to=mail;
	            String toemail=to;
	            
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);
	        // Set From: header field of the header.
	         message.setFrom(new InternetAddress(username));
	        // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO,new InternetAddress(toemail));
	        // Set Subject: header field
	         String sub="OTP";
	         message.setSubject(sub);
	         // Create the message part 
	         BodyPart messageBodyPart = new MimeBodyPart();
	         // Fill the message
	        		         
	         messageBodyPart.setText("Hi you are added in Briga Hospital \nyour username is "+name+"\n and password is "+pswd);			         
	         // Create a multipar message
	         Multipart multipart = new MimeMultipart();

	         // Set text message part
	         multipart.addBodyPart(messageBodyPart);

	         // Part two is attachment
	         //messageBodyPart = new MimeBodyPart();
	         //String filename = file;
	         //DataSource source = new FileDataSource(filename);
	         //messageBodyPart.setDataHandler(new DataHandler(source));
	         //messageBodyPart.setFileName(filename);
	         //multipart.addBodyPart(messageBodyPart);

	         // Send the complete message parts
	         message.setContent(multipart );

	         // Send message
	         Transport.send(message);
	         System.out.println("Sent message successfully....");
	         //date and time
	         SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
	             Date d=new Date();
	             String dat=df.format(d);
	             SimpleDateFormat dft=new SimpleDateFormat("hh:mm:ss");
	             String time=dft.format(d);
	         //take backup    
	         //backup.backupemail(toemail,dat, time);
	        
	      }catch (MessagingException mex) {
	    	  System.out.println("Exception in senMail fu in servvv");
	    	  mex.printStackTrace();
	      }
			return 0;
	   }
	
	public String Admin_logoutCheck()
	{
		regmodel rm=null;
		try
		{
			String s1="SELECT * FROM `login` WHERE `Type`='admin'"; 
			PreparedStatement ps=con.prepareStatement(s1);
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm = new regmodel();
				rm.setStatus(rs.getString(4));
				return rs.getString(4);
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "Notconnected";
		
	}
	
	
	
	
	public int Admin_logout()
	{
		regmodel rm=null;
		try
		{
			String s1="UPDATE `login` SET `status`='Logout' WHERE `Type`='admin'"; 
			PreparedStatement ps=con.prepareStatement(s1);
			System.out.println(ps);
			int rs=ps.executeUpdate();
			while(rs!=0)
			{
				rm = new regmodel();
				rm.setStatus("Logout");
				return rs;	
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	

	public String Doct_dept(int id)
	{
		regmodel rm=null;
		try
		{
			String s1="SELECT * FROM `doctor` WHERE `doctor_id`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setInt(1, id);
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm = new regmodel();
				rm.setDepartment(rs.getString(5));
				return rs.getString(5);
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "0";
		
	}
	public ArrayList<regmodel> PatientByDept(String Dept){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `patient` WHERE `department`=?"); 
			p.setString(1, Dept);
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				Arr.add(rm);
			}
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	
	
	public int Doct_logout(int id)
	{
		regmodel rm=null;
		try
		{
			String s1="UPDATE `login` SET `status`='Logout' WHERE `regid`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setInt(1, id);
			System.out.println(ps);
			int rs=ps.executeUpdate();
			while(rs!=0)
			{
				rm = new regmodel();
				rm.setStatus("Logout");
				return rs;	
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	
	public regmodel login(String un,String pswd)
	{
		regmodel rm=null;
		try
		{ 
			String s1="SELECT * FROM login where  name=? and password=? "; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, un);
			ps.setString(2,pswd);
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm = new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(3));
				rm.setPassword(rs.getString(4));
				System.out.println(rs.getString(5));
				rm.setType(rs.getString(5));
				rm.setStatus(rs.getString(6));
				
				String s2="UPDATE `login` SET `status`='Active' where name=? and password=? ";
				PreparedStatement ps2=con.prepareStatement(s2);
				ps2.setString(1, un);
				ps2.setString(2,pswd);
				int rs2 = ps2.executeUpdate();
				if(rs2!=0)
				{
					rm.setStatus("Active");
				}
				if(rs.getString(5).equals("doctor")){
					rm.setId(rs.getInt(2));
				}
				return rm;	
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rm;
		
	}

	public String Doct_logoutCheck(int id)
	{
		regmodel rm=null;
		try
		{
			String s1="SELECT * FROM `login` WHERE `id`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setInt(1, id);

			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm = new regmodel();
				rm.setStatus(rs.getString(6));
				return rs.getString(6);
			}
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "Notconnected";
		
	}
	public int doc_insert(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `doctor`( `doc_name`, `dob`, `gender`, `department`, `email`, `address`, `phone`) VALUES (?,?,?,?,?,?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				String s2="Insert into login (`regid`, `name`, `password`, `Type`, `status`)values(?,?,?,'doctor','logout')";
				PreparedStatement ps2 = con.prepareStatement(s2);
				ps2.setInt(1, rs.getInt(1));
				ps2.setString(2,rm.getName());
				ps2.setString(3, rm.getPassword());
				System.out.println(ps2);
				ps2.executeUpdate();
				
				ResultSet rs2=ps2.getGeneratedKeys();
				while(rs2.next())
				{
					rm.setId(rs2.getInt(1));
					return rs2.getInt(1);
				}
					
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int reqadd(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `facility`(`Facility`, `Pat_id`) VALUES (?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getDepartment());
			ps.setString(2, rm.getEmail());
			ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				return rs.getInt(1);
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int Patient_insert(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `patient`(`patient_name`, `address`, `phone`, `email`, `gender`, `age`, `blood_group`, `department`) VALUES (?,?,?,?,?,?,?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getAddress());
			ps.setInt(3, rm.getPhone());
			ps.setString(4, rm.getEmail());
			ps.setString(5, rm.getGender());
			ps.setInt(6, rm.getAge());
			ps.setString(7, rm.getBlood());
			ps.setString(8, rm.getDepartment());
			ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				rm.setId( rs.getInt(1));
				return rs.getInt(1);
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	
	
	public int messageadd(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `feedback`(`name`, `email`, `website`, `message`) VALUES (?,?,?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getEmail());
			ps.setString(3, rm.getWebsite());
			ps.setString(4, rm.getMessage());
			ps.executeUpdate();
			System.out.println(ps);
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				return rs.getInt(1);
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int nurse_insert(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `nurse`(`nurse_name`, `dob`, `gender`, `department`, `email`, `address`, `phone`) VALUES (?,?,?,?,?,?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				return rs.getInt(1);
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int staff_insert(regmodel rm)
	{
		
		try
		{
			String s1="INSERT INTO `staff`(`staff_name`, `dob`, `gender`, `department`, `email`, `address`, `phone`) VALUES (?,?,?,?,?,?,?)"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			
			ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
			while(rs.next())
			{
				return rs.getInt(1);
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	
	public int nurse_update(regmodel rm)
	{
		try
		{
			String s1="UPDATE `nurse` SET `nurse_name`=?,`dob`=?,`gender`=?,`department`=?,`email`=?,`address`=?,`phone`=? WHERE `nurse_id`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			ps.setInt(8, rm.getId());
			System.out.println(ps);
			
			ps.executeUpdate();
			return 1;
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	public int staff_update(regmodel rm)
	{
		try
		{
			String s1="UPDATE `staff` SET `staff_name`=?,`dob`=?,`gender`=?,`department`=?,`email`=?,`address`=?,`phone`=? WHERE `staff_id`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			ps.setInt(8, rm.getId());
			System.out.println(ps);
			
			ps.executeUpdate();
			return 1;
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	public int Doctor_update(regmodel rm)
	{
		try
		{
			String s1="UPDATE `doctor` SET `doc_name`=?,`dob`=?,`gender`=?,`department`=?,`email`=?,`address`=?,`phone`=? WHERE `doctor_id`=?"; 
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getDob());
			ps.setString(3, rm.getGender());
			ps.setString(4, rm.getDepartment());
			ps.setString(5, rm.getEmail());
			ps.setString(6, rm.getAddress());
			ps.setInt(7, rm.getPhone());
			ps.setInt(8, rm.getId());
			
			
			System.out.println(ps);
			
			ps.executeUpdate();
			return 1;
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		
		
	}
	
	
	public ArrayList<regmodel> viewnurseList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `nurse`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDepartment(rs.getString(5));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	
	public ArrayList<regmodel> viewstaffList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `staff`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDepartment(rs.getString(5));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	
	public ArrayList<regmodel> viewdoctList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `doctor`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDepartment(rs.getString(5));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	public ArrayList<regmodel> viewPatientList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `patient`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{

				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDepartment(rs.getString(9));
				System.out.println(rs.getString(5));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	public ArrayList<regmodel> viewfeedbackList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `feedback`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{

				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setEmail(rs.getString(3));
				rm.setWebsite(rs.getString(4));
				rm.setMessage(rs.getString(5));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	public ArrayList<regmodel> viewRequestList(){
		regmodel rm=null;
		ArrayList<regmodel> Arr=new ArrayList<regmodel>();
		try{
			PreparedStatement p=con.prepareStatement("SELECT * FROM `facility`");
			java.sql.ResultSet rs=p.executeQuery();
			while(rs.next())
			{

				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setWebsite(rs.getString(2));
				rm.setMessage(rs.getString(3));
				Arr.add(rm);
			}

			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return Arr;
	}
	
	public regmodel NurseSelectbyid(int id)
	{
		regmodel rm=null;
	
		try{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `nurse` WHERE `nurse_id`=?");
			ps.setInt(1,id);
			java.sql.ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDob(rs.getString(3));
				rm.setGender(rs.getString(4));
				rm.setDepartment(rs.getString(5));
				rm.setAddress(rs.getString(8));
				rm.setPhone(rs.getInt(9));
				rm.setEmail(rs.getString(6));
			}
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return rm;
	}
	
	public regmodel DoctorSelectbyid(int id)
	{
		regmodel rm=null;
	
		try{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `doctor` WHERE `doctor_id`=?");
			ps.setInt(1,id);
			java.sql.ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDob(rs.getString(3));
				rm.setGender(rs.getString(4));
				rm.setDepartment(rs.getString(5));
				rm.setAddress(rs.getString(7));
				rm.setPhone(rs.getInt(8));
				rm.setEmail(rs.getString(6));
				
			}
		
			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return rm;
	}

	
	public regmodel StaffSelectbyid(int id)
	{
		regmodel rm=null;
	
		try{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `staff` WHERE `staff_id`=?");
			ps.setInt(1,id);
			java.sql.ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setDob(rs.getString(3));
				rm.setGender(rs.getString(4));
				rm.setDepartment(rs.getString(5));
				rm.setAddress(rs.getString(8));
				rm.setPhone(rs.getInt(9));
				rm.setEmail(rs.getString(6));
				
			}
		
			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return rm;
	}
	
	public regmodel PatientSelectbyid(int id)
	{
		regmodel rm=null;
	
		try{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `patient` WHERE `patient_id`=?");
			ps.setInt(1,id);
			java.sql.ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				rm=new regmodel();
				
				
				rm.setId(rs.getInt(1));
				rm.setName(rs.getString(2));
				rm.setAddress(rs.getString(3));
				rm.setPhone(rs.getInt(4));
				rm.setEmail(rs.getString(5));
				rm.setGender(rs.getString(6));
				rm.setAge(rs.getInt(7));
				rm.setBlood(rs.getString(8));
				rm.setDepartment(rs.getString(9));
				
				
				
			}
		
			
		}
		catch(Exception e){
			e.printStackTrace();
	}
		return rm;
	}
	public int deleteStaff(int id)
	{
		try{
			String s1="DELETE FROM `staff` WHERE `staff_id`=?";
			PreparedStatement ps = con.prepareStatement(s1);
			ps.setInt(1,id);
			ps.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id;
	}
	
	public int deletePatient(int id)
	{
		try{
			String s1="DELETE FROM `patient` WHERE `patient_id`=?";
			PreparedStatement ps = con.prepareStatement(s1);
			ps.setInt(1,id);
			ps.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id;
	}

	public int deleteNurse(int id)
	{
		try{
			String s1="DELETE FROM `nurse` WHERE `nurse_id`=?";
			PreparedStatement ps = con.prepareStatement(s1);
			ps.setInt(1,id);
			ps.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id;
	}
	public int deleteDoctor(int id)
	{
		try{
			String s1="DELETE FROM `doctor` WHERE `doctor_id`=?";
			PreparedStatement ps = con.prepareStatement(s1);
			ps.setInt(1,id);
			ps.executeUpdate();
			String s2="DELETE FROM `login` WHERE `regid`=?";
			PreparedStatement ps2 = con.prepareStatement(s2);
			ps2.setInt(1,id);
			ps2.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id;
	}
	
	
}
