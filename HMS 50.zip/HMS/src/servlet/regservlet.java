package servlet;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.regservice;

import model.regmodel;

/**
 * Servlet implementation class regservlet
 */
@WebServlet("/regservlet")
public class regservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public regservlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String btn=request.getParameter("op");
		System.out.println(btn);
		PrintWriter out = response.getWriter();
		/*if(btn.equals("submit"))
		{
			String pass=request.getParameter("pass");
			String un="admin";
			System.out.println(pass);
			regmodel rm =new regmodel();
			rm.setName(pass);
			regservice rs=new regservice();
			int k=rs.logincheck(un, pass);
			if (k!=0)
			{
				Cookie ck=new Cookie("name","admin");
				response.addCookie(ck);
				
				response.sendRedirect("adminPage.jsp?msg=a");
				
			}
			else
			{
				out.println("<script type=\"text/javascript\">");
			    out.println("alert('User or password incorrect');");
			    out.println("location='adminlogin.jsp';");
			    out.println("</script>");
			}
		}
		*/
		
		if(btn.equals("Add Doctor"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			String ph=request.getParameter("phone");
			String pswd=request.getParameter("pswd");
			regmodel rm =new regmodel();
			try
		    {
		      int phone = Integer.parseInt(ph.trim());
		      System.out.println("int ph = " + phone);
		      rm.setPhone(phone);
		    }
		    catch (NumberFormatException nfe)
		    {
		      System.out.println("NumberFormatException: " + nfe.getMessage());
		    }
			
			String email=request.getParameter("Email");
			
			System.out.println(name+dob+gender+dept+address+email+pswd);
			
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPassword(pswd);
			
			rm.setEmail(email);
			rm.setName(name);
			
			regservice rs=new regservice();
			int k=rs.doc_insert(rm);
			out.println("<script type=\"text/javascript\">");
			try {
				
				rs.senMail(email,pswd,name);
				out.println("alert('Mail sent');");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				out.println("alert('Mail sent error');");
			}
			
			if (k!=0)
			{
				 out.println("alert('Doctor added successfully');");
				
			}
			else
			{
				
			    out.println("alert('User or password incorrect');");
			}
			out.println("location='adddoctor.jsp';");
			out.println("</script>");
		}		
		
		if(btn.equals("Register"))
		{
			String name=request.getParameter("name");
			int age = Integer.parseInt(request.getParameter("age"));
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			String ph=request.getParameter("phone");
			int phone = Integer.parseInt(ph);
			String email=request.getParameter("Email");
			String blood=request.getParameter("blood");
			
			System.out.println(name+age+gender+dept+address+phone+email+blood);
			regmodel rm =new regmodel();
			rm.setName(name);
			rm.setAge(age);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setBlood(blood);
			rm.setPhone(phone);
			rm.setEmail(email);
			
			regservice rs=new regservice();
			int k=rs.Patient_insert(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Patient added successfully');");
				 String loc= "PatientOPTicket.jsp?id="+k;
				 String location= "location="+"'"+loc+"'"+";";
				 out.println(location);
			}
			else
			{
			    out.println("alert('User or password incorrect');");
			}
			out.println("</script>");
		}	
		
		if(btn.equals("Logout"))
		{
			regservice rs=new regservice();
			int k=rs.Admin_logout();
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				Cookie ck=new Cookie("name","");
				ck.setMaxAge(0);
				response.addCookie(ck);
				 out.println("alert('Log out successfully');");
				out.println("location='Home.jsp';");
				 
			}
			else
			{
				
			    out.println("alert('User or password incorrect');");
			}
			out.println("</script>");
		}	
		
		if(btn.equals("DoctLogout"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			regservice rs=new regservice();
			System.out.println("DoctLogout");
			int k=rs.Doct_logout(id);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				Cookie ck=new Cookie("id","");
				ck.setMaxAge(0);
				response.addCookie(ck);
				 out.println("alert('Log out successfully');");
				out.println("location='Home.jsp';");
				 
			}
			else
			{
				
			    out.println("alert('User or password incorrect');");
			}
			out.println("</script>");
		}	
		
		
		
		
		if(btn.equals("Add Nurse"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(name+dob+gender+dept+address+phone+email);
			regmodel rm =new regmodel();
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.nurse_insert(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Nurse added successfully');");
			}
			else
			{
			    out.println("alert('Something is wrong\nData is not inserted');");
			}
			out.println("location='addnurse.jsp';");
			out.println("</script>");
		}	
		
		
		if(btn.equals("Addstaff"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(name+dob+gender+dept+address+phone+email);
			regmodel rm =new regmodel();
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.staff_insert(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Staff added successfully');");
			}
			else
			{
			    out.println("alert('Something is wrong\nData is not inserted');");
			}
			out.println("location='addstaff.jsp';");
			out.println("</script>");
		}	
		
		
		
		if(btn.equals("UpdateNurse"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			
			int id = Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(id+name+dob+gender+dept+address+phone+email);
			regmodel rm =new regmodel();
			rm.setId(id);
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.nurse_update(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Nurse updated successfully');");
				
			}
			else
			{
			    out.println("alert('update failed');");
			}
			out.println("location='NursesList.jsp';");
			out.println("</script>");
		}		
		
		if(btn.equals("UpdateStaff"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			
			
			int id = Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(id+name+dob+gender+dept+address+phone+email);
			regmodel rm =new regmodel();
			rm.setId(id);
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.staff_update(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Staff updated successfully');");
				
			}
			else
			{
			    out.println("alert('update failed');");
			}
			out.println("location='staffsList.jsp';");
			out.println("</script>");
		}	
		
		if(btn.equals("EditDoctor"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			int id = Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			String pswd=request.getParameter("pswd");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(id+name+dob+gender+dept+address+phone+email+pswd);
			regmodel rm =new regmodel();
			rm.setId(id);
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPassword(pswd);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.Doctor_update(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Doctor updated successfully');");
				 String loc= "DoctorsPage.jsp?id="+id;
				 String location= "location="+"'"+loc+"'"+";";
				 out.println(location);
				 
			}
			else
			{
				
			    out.println("alert('update failed');");
			}
			
			out.println("</script>");
			  
		}	
		
		if(btn.equals("UpdateDoctor"))
		{
			
			
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			
			int id = Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			String dob = request.getParameter("dob");
			String gender = request.getParameter("gender");
			String dept=request.getParameter("dep");
			String address=request.getParameter("address");
			String pswd=request.getParameter("pswd");
			int phone = Integer.parseInt(request.getParameter("phone"));
			String email=request.getParameter("Email");
			
			System.out.println(id+name+dob+gender+dept+address+phone+email+pswd);
			regmodel rm =new regmodel();
			rm.setId(id);
			rm.setName(name);
			rm.setDob(dob);
			rm.setGender(gender);
			rm.setDepartment(dept);
			rm.setAddress(address);
			rm.setPassword(pswd);
			rm.setPhone(phone);
			rm.setEmail(email);
			rm.setName(name);
			regservice rs=new regservice();
			int k=rs.Doctor_update(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Doctor updated successfully');");
				
			}
			else
			{
				
			    out.println("alert('update failed');");
			}
			out.println("location='DoctorsList.jsp';");
			out.println("</script>");
		}	
		if(btn.equals("Send"))
		{
			String name=request.getParameter("name");
			String email = request.getParameter("email");
			String website = request.getParameter("website");
			String message=request.getParameter("message");
			
			System.out.println(name+email+website+message);
			regmodel rm =new regmodel();
			rm.setName(name);
			rm.setEmail(email);
			rm.setWebsite(website);
			rm.setMessage(message);
			regservice rs=new regservice();
			int k=rs.messageadd(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Message send successfully');");
				
			}
			else
			{
				
			    out.println("alert('Messaging failed');");
			}
			out.println("location='contact.jsp';");
			out.println("</script>");
		}
		if(btn.equals("Confirm"))
		{
			Cookie ck[]=request.getCookies();
			if(ck!=null){
			 String name=ck[0].getValue();
			if(!name.equals("")||name!=null){
			}
			}else{
				out.print("Please login first");
				request.getRequestDispatcher("Home.jsp").include(request, response);
			}
			String dep=request.getParameter("dep");
			String email=request.getParameter("email");
			int id = Integer.parseInt(request.getParameter("id"));
			
			System.out.println(dep+id);
			regmodel rm =new regmodel();
			rm.setDepartment(dep);
			rm.setEmail(email);
			regservice rs=new regservice();
			int k=rs.reqadd(rm);
			out.println("<script type=\"text/javascript\">");
			if (k!=0)
			{
				 out.println("alert('Request send successfully');");
				 String loc= "ReserveFacility.jsp?id="+id;
				 String location= "location="+"'"+loc+"'"+";";
				 out.println(location);
				 
				
			}
			else
			{
				
			    out.println("alert('Messaging failed');");
			}
			out.println("</script>");
		}	
	}
}

