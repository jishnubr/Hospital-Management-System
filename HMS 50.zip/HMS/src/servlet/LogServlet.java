package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.regmodel;
import service.regservice;

/**
 * Servlet implementation class LogServlet
 */
@WebServlet("/LogServlet")
public class LogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Login=request.getParameter("Login");
		System.out.println(Login);
		PrintWriter out = response.getWriter();
		if(Login.equals("Login"))
		{
			String pass=request.getParameter("pswd");
			String un=request.getParameter("name");
			System.out.println(pass+un);
			regmodel rm =new regmodel();
			rm.setName(un);
			rm.setPassword(pass);
			regservice rs=new regservice();
			regmodel k=rs.login(un,pass);
			if (k!=null)
			{
				Cookie ck=new Cookie("id",Integer.toString (k.getId()));
				response.addCookie(ck);
				if(k.getType().equals("doctor")) {
					response.sendRedirect("DoctorsPage.jsp?id="+k.getId());
				}
				if(k.getType().equals("admin")) {
					response.sendRedirect("adminPage.jsp");
				}
			}
			else
			{
				out.println("<script type=\"text/javascript\">");
			    out.println("alert('User or password incorrect');");
			    out.println("location='Login.jsp';");
			    out.println("</script>");
			}
		}
	}

}
